# atlas-notes

A tiny note keeper.
