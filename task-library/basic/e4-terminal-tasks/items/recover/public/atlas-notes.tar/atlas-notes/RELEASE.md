# Release notes

## 1.0

- Notes can be added and listed.
