"""Notes: add, list, count."""

NOTES = []  # in insertion order


def add(text):
    NOTES.append(text)


def listing():
    return list(NOTES)


def count():
    return len(NOTES)
